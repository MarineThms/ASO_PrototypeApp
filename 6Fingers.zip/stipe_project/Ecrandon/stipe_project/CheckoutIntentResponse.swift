//
//  CheckoutIntentResponse.swift
//  FruitStore
//
//  Created by Mohammad Azam on 10/7/21.
//

import Foundation


struct CheckoutIntentResponse: Decodable {
    let clientSecret: String
}
