//
//  Fruits_Stripe_IntegrationApp.swift
//  Fruits-Stripe-Integration
//
//  Created by marco rodriguez on 01/07/22.
//

//import SwiftUI
//import StripeCore
//
//@main
//struct Fruits_Stripe_IntegrationApp: App {
//    
//    init() {
//        StripeAPI.defaultPublishableKey = "pk_test_51MX3DMHS96iekusSoa56mm6j6pEzz0dcuXVG0Enhcrs40LSTMdtdXI7Q4hgTeCWcsENobADzgmneXDvm1O1Io1Tl00diRHGDhJ"
//    }
//    
//    var body: some Scene {
//        WindowGroup {
//            ContentView().environmentObject(Cart())
//        }
//    }
//}
